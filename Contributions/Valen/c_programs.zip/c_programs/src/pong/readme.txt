PONG v0.01
----------

Menu keys:
Joy 1 fire or keyb X - one player game
Joy 2 fire or keyb , - two players game
1 - Credits
ESC - Exit

Game keys:
P - pause
LeftShift - show frame time

Joy 1 up/down or keyb A/Z - move bat 1
Joy 1 fire or keyb X - fire with rocket
for two players mode:
Joy 2 up/down or keyb J/M - move bat 2
Joy 2 fire or keyb , - fire with rocket

Get 10 scores to win!