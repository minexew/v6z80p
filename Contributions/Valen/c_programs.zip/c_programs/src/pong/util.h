#define CLEAR_IRQ_KEYBOARD      1
