Memory buffers used
--------------------
byte* tmp1 = (byte*) 0xXXXX;