#define SET_STACK()     const word own_sp = OWN_SP;     // OWN_SP is defined in project makefile
SET_STACK()                                             // set stack address for this program (actual value is in project makefile)
