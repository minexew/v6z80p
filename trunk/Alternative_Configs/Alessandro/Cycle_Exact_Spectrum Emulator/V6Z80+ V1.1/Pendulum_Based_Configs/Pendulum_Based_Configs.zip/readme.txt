
These are the best working Pendulum-based Spectrum cores so far,
compiled by Phil with the setting "keep hierarchy = soft"

The feedback from users was has been good, only Alessandro himself
reported problems with them on his particular V6Z80P.

